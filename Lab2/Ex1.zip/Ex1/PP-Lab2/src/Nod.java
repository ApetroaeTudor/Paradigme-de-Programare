public class Nod {
    Nod succ;
    String data;
}
